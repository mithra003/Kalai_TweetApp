package com.tweetapp.console_based_app.utils;

public class ViewController {
	
	public void notLoggedIn() {
		
	}

}
